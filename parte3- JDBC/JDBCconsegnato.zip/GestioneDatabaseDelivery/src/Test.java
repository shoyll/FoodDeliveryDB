import java.sql.*;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws SQLException {

        sc.useDelimiter("\n");

        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/delivery", username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

       try{
           int scelta;

           do{
               System.out.println("\n\n");
               System.out.println("Scegli un'operazione: ");
               System.out.println("1 - Registrazione di un ordine ");
               System.out.println("2 - Consegna di un ordine ");
               System.out.println("3 - Disponibilita' di un ristorante a ricevere un nuovo ordine");
               System.out.println("4 - Visualizza ristoranti disponibili all'accettazione di un ordine");
               System.out.println("5 - Valutazione di un raider");
               System.out.println("6 - Numero Ordini per cliente");
               System.out.println("7 - Abilitazione di una societa' ad un servizio di delivery");
               System.out.println("8 - Assunzione di un nuovo dipendente");
               System.out.println("9 - Visualizzazione dei nomi dei ristoranti che impiegano dipendenti propri per la consegna o che si affidano ai servizi della società «Food Delivery»");
               System.out.println("10 - Visualizzazione degli ordini effettuati da rider ancora non valutati");
               System.out.println("11 - Eliminare un ordine non consegnato");
               System.out.println("12 - Stampa di tutte le persone (nome, cognome) che abbiano consegnato ordini a Giuseppe Verdi nell�ultima settimana");
               System.out.println("13 - Report dei ristoranti con coda ordini attuale");
               System.out.println("14 - REPORT settimanale dei rider");
               System.out.println("15 - Stampa settimanale di tutti i clienti che nell’ultima settimana abbiano effettuato almeno una valutazione inferiore al corrispondente score medio di un raider");
               System.out.println("\n16 - ESCI");
               System.out.print("Scelta: ");
               scelta = sc.nextInt();

               switch(scelta){
                   case 1 :
                       es1();
                       break;

                   case 2 :
                       es2();
                       break;

                   case 3 :
                       es3();
                       break;

                   case 4 :
                       es4();
                       break;

                   case 5 :
                       es5();
                       break;

                   case 6 :
                       es6();
                       break;

                   case 7 :
                       es7();
                       break;

                   case 8 :
                       es8();
                       break;

                   case 9 :
                       es9();
                       break;

                   case 10 :
                       es10();
                       break;

                   case 11 :
                       es11();
                       break;

                   case 12 :
                       es12();
                       break;

                   case 13 :
                       es13();
                       break;

                   case 14 :
                       es14();
                       break;

                   case 15 :
                       es15();
                       break;

                   case 16 :
                       return;
               }
           }while(scelta != 0);
       }catch(Exception e){
           e.printStackTrace();
       }
    }

    static void es1(){
        try {
            PreparedStatement statement;
            ResultSet rs;
            statement = conn.prepareStatement("INSERT INTO ordine VALUES (0,?,?,?,?,?,?,?,?,?,?,?)");

            String dataOrdinazione,orarioEffettivo,stato,tipo,orarioConsegnaPresunto,nominativoRitiro,nomeRistorante,indirizzoRistorante,
                    cfDipendente,cfRider,cfCliente;

            sc.nextLine();

            System.out.println("Consegna un dipendente o un rider? (0- Dipendente, 1- Rider) : ");
            if(sc.nextInt() == 0) {
                sc.nextLine();
                System.out.println("Codice Fiscale del Dipendente : ");
                cfDipendente = sc.nextLine();
                statement.setString(10,null);
                statement.setString(9,cfDipendente);

            }else{
                sc.nextLine();
                System.out.println("Codice Fiscale del Rider : ");
                cfRider = sc.nextLine();
                statement.setString(10,cfRider);
                statement.setString(9,null);
            }

            System.out.println("Data Ordinazione (yyyy-mm-dd) : ");
            dataOrdinazione = sc.nextLine();
            System.out.println("Orario Effettivo (hh:mm) : ");
            orarioEffettivo = sc.nextLine();
            System.out.println("Stato ['Ordinato','Espletato','Consegnato']  : ");
            stato = sc.nextLine();
            System.out.println("Tipo : ");
            tipo = sc.nextLine();
            System.out.println("Orario Consegna Presunto (hh:mm) : ");
            orarioConsegnaPresunto = sc.nextLine();
            System.out.println("Nominativo Ritiro : ");
            nominativoRitiro = sc.nextLine();
            System.out.println("Nome Ristorante : ");
            nomeRistorante = sc.nextLine();
            System.out.println("Indirizzo Ristorante : ");
            indirizzoRistorante = sc.nextLine();
            System.out.println("Codice Fiscale del Cliente : ");
            cfCliente = sc.nextLine();

            statement.setString(1,dataOrdinazione);
            statement.setString(2,orarioEffettivo);
            statement.setString(3,stato);
            statement.setString(4,tipo);
            statement.setString(5,orarioConsegnaPresunto);
            statement.setString(6,nominativoRitiro);
            statement.setString(7,nomeRistorante);
            statement.setString(8,indirizzoRistorante);
            statement.setString(11,cfCliente);



            System.out.println(statement.executeUpdate() + " righa/e modificata/e ");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void es2() throws SQLException {
        int id;
        System.out.println("Inserire ID Dell'ordine da consegnare: ");
        id = sc.nextInt();

        String idString = Integer.toString(id);

        PreparedStatement st;
        st = conn.prepareStatement("UPDATE Ordine SET stato = 'Consegnato' WHERE nOrdine = ?");

        st.setString(1,idString);

        if(st.executeUpdate() > 0){
            System.out.println("Ordine numero " + idString + " consegnato.");
        }else{
            System.out.println("Ordine numero " + idString + " non trovato.");
        }
    }

    static void es3() throws SQLException {
        sc.nextLine();
        Statement st;
        ResultSet rs;

        String nomeRistorante;
        System.out.println("Nome Ristorante : ");
        nomeRistorante = sc.nextLine();

        st = conn.createStatement();
        rs = st.executeQuery("select maxPrenotazioni,nome,count(*) as numeroOrdini from ristorante left join ordine ON nome = nomeRistorante AND indirizzo = indirizzoRistorante WHERE stato <> \"Consegnato\" OR stato is null GROUP BY nome HAVING numeroOrdini < maxPrenotazioni");

        int trovato = 0;

        while(rs.next()){
            if(rs.getString("nome").equalsIgnoreCase(nomeRistorante)) trovato = 1;
        }

        if (trovato == 1){
            System.out.println("Ristorante disponibile ad accettare nuovi ordini");
        }else{
            System.out.println("Coda Ordini Piena");
        }

    }

    static void es4() throws SQLException {
        Statement st;
        ResultSet rs;

        st = conn.createStatement();
        rs = st.executeQuery("select maxPrenotazioni,nome,count(*) as numeroOrdini from ristorante left join ordine ON nome = nomeRistorante AND indirizzo = indirizzoRistorante WHERE stato <> \"Consegnato\" OR stato is null GROUP BY nome HAVING numeroOrdini < maxPrenotazioni");

        while(rs.next()){
            System.out.println(rs.getString("nome"));
        }


    }

    static void es5() throws SQLException {
        sc.nextLine();
        PreparedStatement st = conn.prepareStatement("INSERT INTO Valutazione VALUES(?,?,?,?)");

        String dataValutazione;
        String score;
        String cfCliente;
        String cfRaider;

        System.out.println("Data Valutazione (yyyy-mm-dd) : ");
        dataValutazione = sc.nextLine();
        st.setString(1,dataValutazione);
        System.out.println("Score (da 1 a 5) : ");
        score = sc.nextLine();
        st.setString(2,score);
        System.out.println("Codice Fiscale del Cliente : ");
        cfCliente = sc.nextLine();
        st.setString(3,cfCliente);
        System.out.println("Codice Fiscale del Raider : ");
        cfRaider = sc.nextLine();
        st.setString(4,cfRaider);

        System.out.println(st.executeUpdate() + " righa/e modificata/e ");
    }

    static void es6() throws SQLException {
        Statement st = conn.createStatement();
        ResultSet rs;

        String sql = "select nome,cognome, count(cf) as nOrdini from ordine o join cliente c on o.cfCliente = c.cf GROUP BY nome";

        rs = st.executeQuery(sql);

        while(rs.next()){
            System.out.println(rs.getString("Nome") + " " + rs.getString("Cognome") + " " + rs.getString("nOrdini"));
        }

    }

    static void es7() throws SQLException {
        sc.nextLine();
        PreparedStatement st = conn.prepareStatement("INSERT INTO delivery_esterno VALUES (?,?,?,?,?,?,?)");

        String codice;
        String descrizione;
        String cadenzaSettimanale;
        String dataInizio;
        String nomeRistorante;
        String indirizzoRistorante;
        String ivaSocieta;

        System.out.println("Nuovo codice Delivery: ");
        codice = sc.nextLine();
        st.setString(1,codice);

        System.out.println("Descrizione: ");
        descrizione = sc.nextLine();
        st.setString(2,descrizione);

        System.out.println("Cadenza Settimanale: ");
        cadenzaSettimanale = sc.nextLine();
        st.setString(3,cadenzaSettimanale);

        System.out.println("Data inizio (yyyy-mm-dd) : ");
        dataInizio = sc.nextLine();
        st.setString(4,dataInizio);

        System.out.println("Nome Ristorante: ");
        nomeRistorante = sc.nextLine();
        st.setString(5,nomeRistorante);

        System.out.println("Indirizzo Ristorante: ");
        indirizzoRistorante = sc.nextLine();
        st.setString(6,indirizzoRistorante);

        System.out.println("Iva Societa: ");
        ivaSocieta = sc.nextLine();
        st.setString(7,ivaSocieta);

        System.out.println(st.executeUpdate() + " righa/e modificata/e ");
    }

    static void es8() throws SQLException {
        sc.nextLine();
        PreparedStatement st = conn.prepareStatement("insert into dipendente values (?,?,?,?,?,?,?,?,?,?,?,?);");

        String cf ;
        String nome;
        String cognome;
        String indirizzo;
        String dataNascita ;
        String email ;
        String shortCurriculum ;
        int disponibilita ;
        int anniEsperienza ;
        String tipoContratto ;
        String dataInizio ;
        String codiceDelivery ;

        System.out.println("Codice fiscale:");
        cf = sc.nextLine();
        st.setString(1,cf);
        System.out.println("Nome: ");
        nome= sc.nextLine();
        st.setString(2,nome);
        System.out.println("cognome: ");
        cognome = sc.nextLine();
        st.setString(3,cognome);
        System.out.println("indirizzo: ");
        indirizzo= sc.nextLine();
        st.setString(4,indirizzo);
        System.out.println("Data di nascita (yyyy-mm-dd) :");
        dataNascita= sc.nextLine();
        st.setString(5,dataNascita);
        System.out.println("e-mail: ");
        email = sc.nextLine();
        st.setString(6,email);
        System.out.println("breve curriculum: ");
        shortCurriculum= sc.nextLine();
        st.setString(7,shortCurriculum);
        System.out.println("Disponibilit� (0=false/1=true): ");
        disponibilita= sc.nextInt();
        sc.nextLine(); //debug input buffer
        st.setInt(8,disponibilita);
        System.out.println("Anni d'esperienza: ");
        anniEsperienza = sc.nextInt();
        sc.nextLine(); //debug input buffer
        st.setInt(9,anniEsperienza);
        System.out.println("Tipo contratto (Part-Time / Full-Time): ");
        tipoContratto= sc.nextLine();
        st.setString(10,tipoContratto);
        System.out.println("Data d'inizio (yyyy-mm-dd) :");
        dataInizio= sc.nextLine();
        st.setString(11,dataInizio);
        System.out.println("Codice Delivery interno: ");
        codiceDelivery = sc.nextLine();
        st.setString(12,codiceDelivery);

        System.out.println(st.executeUpdate() + " righa/e modificata/e ");
    }

    static void es9() throws SQLException {
        Statement st = conn.createStatement();
        ResultSet rs;
        String sql = "SELECT DISTINCT i.nomeRistorante from delivery_interno i join delivery_esterno e join dipendente WHERE i.codice in (SELECT codiceDelivery FROM dipendente) OR ivaSocieta = \"18374283923\"";

        rs = st.executeQuery(sql);

        while(rs.next()){
            System.out.println(rs.getString("i.nomeRistorante"));
        }
    }

    static void es10() throws SQLException{
    	/* ESE 10
    	#in mysql non c'� l'except ma ci sta il NOT IN

    	select cf, nome, cognome from rider where cf not in (select cf from rider join valutazione on cf=cfRider); #mi da tutti i rider che ancora non sono stati valutati
    	 #ora di questi restituiti io voglio sapere, per ognuno di questi, gli ordine che ha effettuato.


    	POSSIBILE SOLUZIONE: select * from ordine join (select cf, nome, cognome from rider where cf not in (select cf from rider join valutazione on cf=cfRider)) on cf=cfRider;


    	#SOLUZIONE 10: pTable sta per tabella parziale
    	select pTable.nome, pTable.cognome, pTable.cf, nOrdine, dataOrdinazione, orarioEffettivo, stato, tipo,  orarioConsegnaPresunto,nominativoRitiro,
		nomeRistorante, indirizzoRistorante, cfCliente
		from ordine o join (select cf, nome, cognome from rider where cf not in (select cf from rider join valutazione on cf=cfRider)) pTable on pTable.cf=o.cfRider; */


        Statement st;
        ResultSet rs;

        st = conn.createStatement();
        rs = st.executeQuery("select pTable.nome, pTable.cognome, pTable.cf, nOrdine, dataOrdinazione, orarioEffettivo, stato, tipo, orarioConsegnaPresunto, nominativoRitiro,"
                + "	nomeRistorante, indirizzoRistorante, cfCliente"
                + "	from ordine o join (select cf, nome, cognome from rider where cf not in (select cf from rider join valutazione on cf=cfRider)) pTable on pTable.cf=o.cfRider;");


        System.out.println("nomeRider\tcognomeRider\t\tcfRider\t\t\tnOrdine\t\tdataOrdinazione\torarioEffettivo\tstato\t\ttipo\torarioConsegnaPresunto\tnominativoRitiro\t"
                +"nomeRistorante\tindirizzoRistorante\tcfCliente");

        while(rs.next()){
            System.out.println(rs.getString("Nome") + "\t\t" + rs.getString("Cognome") + "\t\t" + rs.getString("cf") + "\t" + rs.getString("nOrdine") + "\t"
                    + "\t" + rs.getString("dataOrdinazione") + "\t" + rs.getString("orarioEffettivo") + "\t" + rs.getString("stato") + "\t" + rs.getString("tipo")
                    + "\t" + rs.getString("orarioConsegnaPresunto") + "\t" + rs.getString("nominativoRitiro") + "\t" + rs.getString("nomeRistorante")
                    + "\t" + rs.getString("indirizzoRistorante") + "\t" + rs.getString("cfCliente"));
        }

    }

    static void es11() throws SQLException {
        Statement st = conn.createStatement();

        int nOrdine;

        System.out.println("Inserire numero dell'ordine da eliminare: ");
        nOrdine = sc.nextInt();

        String sql = "DELETE FROM ordine WHERE nOrdine = " + nOrdine + " AND stato <> \"Consegnato\"";

        int righeModificate = st.executeUpdate(sql);

        if (righeModificate == 0){
            System.out.println("Impossibile eliminare!");
        }else{
            System.out.println("Ordine " + nOrdine + " eliminato.");
        }




    }

    static void es12() throws SQLException{
        /* Stampa di tutte le persone (nome, cognome) che abbiano consegnato ordini (sia Rider che dipendenti) a Giuseppe Verdi nell�ultima settimana */

    	/*
    	1->Query totale legibile [cerca un solo Giueseppe Verdi dal suo codice fiscale]

    	( select distinct nome, cognome from ordine join rider on cfRider=cf where Ordine.cfCliente='VRDGPP76A01B444B' and Ordine.stato='Consegnato' and Ordine.dataOrdinazione >= current_date()-7 )
    	union
    	( select distinct nome, cognome from ordine join dipendente on cfDipendente=cf where Ordine.cfCliente='VRDGPP76A01B444B' and Ordine.stato='Consegnato' and Ordine.dataOrdinazione >= current_date()-7 );

	    2->query alternativa  in[in caso di omonimi restituisce i fattorini per tutti i Giuseppe Verdi, perch� effetua la ricerca tramite nome e cognome]

	    select nome, cognome
		from (select cf, nome, cognome from rider union select cf, nome, cognome from dipendente) fattoriniTutti,
		(select cfDipendente, cfRider from Ordine join cliente on cfCliente=cf
		where cliente.nome='Giuseppe' and cliente.cognome='Verdi' and Ordine.stato='Consegnato' and (Ordine.dataOrdinazione >= current_date()-7)) cfFattoriniGiuseppeVerdi
		where fattoriniTutti.cf=cfFattoriniGiuseppeVerdi.cfDipendente or fattoriniTutti.cf=cfFattoriniGiuseppeVerdi.cfRider;

	    */

        Statement st;
        ResultSet rs;

        st = conn.createStatement();
        rs = st.executeQuery("select nome, cognome "
                + "from (select cf, nome, cognome from rider union select cf, nome, cognome from dipendente) fattoriniTutti, "
                + "(select cfDipendente, cfRider from Ordine join cliente on cfCliente=cf "
                + "where cliente.nome='Giuseppe' and cliente.cognome='Verdi' and Ordine.stato='Consegnato' and (Ordine.dataOrdinazione >= current_date()-7)) cfFattoriniGiuseppeVerdi "
                + "where fattoriniTutti.cf=cfFattoriniGiuseppeVerdi.cfDipendente or fattoriniTutti.cf=cfFattoriniGiuseppeVerdi.cfRider;");

        System.out.println("\nNOME\t\tCOGNOME\n");

        while(rs.next()) System.out.println(rs.getString("nome") + "\t\t" + rs.getString("cognome"));

    }

    static void es13() throws SQLException {
        Statement st = conn.createStatement();
        ResultSet rs;

        String sql = "select * from ristorante";

        rs = st.executeQuery(sql);

        while(rs.next()){
            System.out.println("\n\n");
            System.out.println(rs.getString(1));
            System.out.println(rs.getString(2));
            System.out.println(rs.getString(3));
            System.out.println(rs.getString(4));
            System.out.println(rs.getString(5) + "\n");

            Statement stOrdini;
            ResultSet rsOrdini;

            stOrdini = conn.createStatement();

            rsOrdini = stOrdini.executeQuery("select * from ordine WHERE nomeRistorante = " + "\"" + rs.getString(1) + "\"" + " AND stato <> \"Consegnato\"");



            while(rsOrdini.next()){

                System.out.println(rsOrdini.getString("nOrdine") + " " + rsOrdini.getString("dataOrdinazione")  + " " + rsOrdini.getString("stato")  + " " + rsOrdini.getString("tipo")  + " " + rsOrdini.getString("orarioConsegnaPresunto"));
            }

            System.out.println("________________________________________________________________");

        }
    }

    static void es14() throws SQLException{
        /* Stampa settimanale di un report che mostri i dati dei rider, incluso lo score medio ottenuto nelle valutazioni da parte dei clienti;*/

        Statement st;
        ResultSet rs;

        st = conn.createStatement();
        rs = st.executeQuery("select nome, cognome, cf, avg(score) as scoreMedio, indirizzo, dataNascita, disponibilita, tipo "
                + "from Rider left join Valutazione on cfRider=cf group by (cfRider);");

        System.out.println("\n[nome, cognome, cf, scoreMedio, indirizzo, dataNascita, disponibilita, tipo]\n");

        while(rs.next()) System.out.println(rs.getString("nome") + "\t\t" + rs.getString("cognome") + "\t\t"+  rs.getString("cf")  + "\t\t" + rs.getString("scoreMedio")
                + "\t\t"+  rs.getString("indirizzo") + "\t\t" + rs.getString("dataNascita")+ "\t\t"+  rs.getString("disponibilita") + "\t\t" + rs.getString("tipo"));
    }

    static void es15() throws SQLException {
        Statement st = conn.createStatement();
        ResultSet rs;

        String sql = "select nome,cognome from cliente join valutazione v on cf = cfCliente WHERE score <\n" +
                "\n" +
                "(select AVG(score) from valutazione v1 join rider on cfRider = cf WHERE v.cfRider = v1.cfRider GROUP BY cf)";

        rs = st.executeQuery(sql);

        while(rs.next()){
            System.out.print(rs.getString(1) + " " + rs.getString(2));
        }
    }

    static Connection conn = null;
    static String username = "root";
    static String password = "password";
    static Scanner sc = new Scanner(System.in);
}
